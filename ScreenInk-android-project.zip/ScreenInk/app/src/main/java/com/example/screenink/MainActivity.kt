package com.example.screenink

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.core.widget.doAfterTextChanged
import kotlin.math.sin

class PreviewView(c: Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onMeasure(w: Int, h: Int) = setMeasuredDimension(MeasureSpec.getSize(w), (resources.displayMetrics.density * 180).toInt())
    override fun onDraw(cv: Canvas) {
        val W = width.toFloat(); val H = height.toFloat()
        p.style = Paint.Style.FILL; p.color = 0xFF1E1E2C.toInt(); cv.drawRoundRect(0f, 0f, W, H, 30f, 30f, p)
        val col = P.i(context, "laserColor"); val sz = P.i(context, "laserSize").toFloat(); val n = 24
        fun xx(k: Int) = W * (0.08f + 0.6f * k / n); fun yy(k: Int) = H * 0.28f + 20f * sin(k * 0.45f)
        p.style = Paint.Style.STROKE; p.strokeCap = Paint.Cap.ROUND
        for (k in 1..n) {
            val f = k / n.toFloat()
            p.color = (col and 0xFFFFFF) or ((110 * f).toInt() shl 24); p.strokeWidth = sz * 1.8f * f + 2; cv.drawLine(xx(k - 1), yy(k - 1), xx(k), yy(k), p)
            p.color = (col and 0xFFFFFF) or ((255 * f).toInt() shl 24); p.strokeWidth = sz * 0.7f * f + 1; cv.drawLine(xx(k - 1), yy(k - 1), xx(k), yy(k), p)
        }
        p.style = Paint.Style.FILL
        p.color = (col and 0xFFFFFF) or (80 shl 24); cv.drawCircle(xx(n), yy(n), sz * 2f, p)
        p.color = col; cv.drawCircle(xx(n), yy(n), sz, p); p.color = Color.WHITE; cv.drawCircle(xx(n), yy(n), sz * 0.4f, p)
        val pc = P.i(context, "color"); p.style = Paint.Style.STROKE; p.strokeCap = Paint.Cap.ROUND
        p.color = pc; p.strokeWidth = P.i(context, "penSize").toFloat(); cv.drawLine(W * 0.08f, H * 0.62f, W * 0.6f, H * 0.62f, p)
        p.color = (pc and 0xFFFFFF) or (90 shl 24); p.strokeWidth = P.i(context, "hlSize").toFloat().coerceAtMost(60f); cv.drawLine(W * 0.08f, H * 0.82f, W * 0.6f, H * 0.82f, p)
    }
}

class MainActivity : Activity() {
    private lateinit var box: LinearLayout
    private lateinit var preview: View
    private lateinit var status: TextView
    private lateinit var go: Button
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun tv(t: String, s: Float, c: Int) = TextView(this).apply { text = t; textSize = s; setTextColor(c); setPadding(0, dp(6), 0, dp(2)) }
    private fun head(t: String) = box.addView(tv(t, 13f, 0xFFFF6E6E.toInt()).apply { setPadding(0, dp(22), 0, dp(4)); letterSpacing = 0.15f })

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(28), dp(20), dp(40)) }
        setContentView(ScrollView(this).apply { setBackgroundColor(0xFF12121A.toInt()); addView(box) })
        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        top.addView(ImageView(this).apply { setImageResource(R.mipmap.ic_launcher) }, LinearLayout.LayoutParams(dp(76), dp(76)))
        val names = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), 0, 0, 0) }
        names.addView(tv("ScreenInk", 28f, Color.WHITE).apply { typeface = Typeface.DEFAULT_BOLD })
        names.addView(tv("Draw • Point • Capture • Ask AI", 13f, 0xFF9E9EB8.toInt()))
        top.addView(names); box.addView(top)
        status = tv("", 14f, 0xFFB0B0C8.toInt()); box.addView(status)
        go = Button(this).apply {
            setTextColor(Color.WHITE); isAllCaps = false; textSize = 17f
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(0xFF6A1B9A.toInt(), 0xFFE53935.toInt())).apply { cornerRadius = dp(14).toFloat() }
            setOnClickListener {
                if (OverlayService.running) startService(Intent(this@MainActivity, OverlayService::class.java).setAction("STOP"))
                else if (!Settings.canDrawOverlays(this@MainActivity)) {
                    Toast.makeText(this@MainActivity, "Allow \"Display over other apps\", then tap Start again", Toast.LENGTH_LONG).show()
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                } else startForegroundService(Intent(this@MainActivity, OverlayService::class.java))
                postDelayed({ refresh() }, 600)
            }
        }
        box.addView(go, LinearLayout.LayoutParams(-1, dp(56)).apply { topMargin = dp(10) })
        head("LIVE PREVIEW"); preview = PreviewView(this); box.addView(preview)
        head("LASER POINTER")
        slider("Laser size", "laserSize", 4, 60, 2, "px")
        slider("Laser fade time", "laserTime", 200, 5000, 100, "ms")
        colors("Laser color", "laserColor")
        head("PEN, BRUSH, HIGHLIGHTER, SHAPES")
        slider("Pen / shape width", "penSize", 1, 40, 1, "px")
        slider("Brush size", "brushSize", 4, 80, 2, "px")
        slider("Highlighter size", "hlSize", 8, 100, 2, "px")
        slider("Eraser size", "eraserSize", 10, 150, 5, "px")
        slider("Stamp size", "stampSize", 30, 300, 10, "px")
        colors("Drawing color", "color")
        head("ASK AI (GEMINI)")
        box.addView(tv("Get a free key at aistudio.google.com/apikey, then paste it here.", 12f, 0xFF9E9EB8.toInt()))
        field("Gemini API key", "apiKey"); field("Model", "model"); field("Question sent with the circled area", "prompt")
        head("HOW TO USE")
        box.addView(tv("Tap Start, open any app, tap the ✨ bubble to open the toolbar.\n" +
            "🔴 laser  ✏️ pen  🖌️ brush  🖍️ highlighter  🧽 eraser  ╱ ➜ ▭ ◯ shapes  ⭐ stamps\n" +
            "↩️ undo  🗑️ clear  ✂️ screenshot an area  🔍 circle to ask AI\n" +
            "👆 / ✍️ switches between using the app underneath and drawing.", 13f, 0xFFCCCCDD.toInt()))
    }

    private fun refresh() {
        go.text = if (OverlayService.running) "⏹  Stop overlay" else "▶  Start overlay"
        status.text = if (OverlayService.running) "Running. Look for the ✨ bubble on your screen." else "Overlay is off."
    }
    override fun onResume() { super.onResume(); refresh() }

    private fun slider(label: String, key: String, min: Int, max: Int, step: Int, unit: String) {
        val t = tv("", 14f, 0xFFCCCCDD.toInt()); val s = SeekBar(this)
        s.max = (max - min) / step; val cur = P.i(this, key); s.progress = (cur - min) / step
        fun upd(v: Int) { t.text = "$label:  $v $unit" }; upd(cur)
        s.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, u: Boolean) { val v = min + p * step; P.put(this@MainActivity, key, v); upd(v); preview.invalidate() }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        box.addView(t); box.addView(s)
    }

    private fun colors(label: String, key: String) {
        box.addView(tv(label, 14f, 0xFFCCCCDD.toInt()))
        val g = GridLayout(this).apply { columnCount = 5 }
        intArrayOf(0xFFFF1744.toInt(), 0xFFFF9100.toInt(), 0xFFFFEA00.toInt(), 0xFF00E676.toInt(), 0xFF00E5FF.toInt(),
            0xFF2979FF.toInt(), 0xFFD500F9.toInt(), 0xFFFF4081.toInt(), Color.WHITE, Color.BLACK).forEach { c ->
            val v = View(this).apply { background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(c); setStroke(3, 0x88FFFFFF.toInt()) } }
            v.setOnClickListener { P.put(this, key, c); preview.invalidate() }
            g.addView(v, GridLayout.LayoutParams().apply { width = dp(42); height = dp(42); setMargins(dp(5), dp(5), dp(5), dp(5)) })
        }
        box.addView(g); box.addView(tv("Custom color (slide the hue)", 12f, 0xFF888899.toInt()))
        box.addView(SeekBar(this).apply {
            max = 360
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, u: Boolean) { if (u) { P.put(this@MainActivity, key, Color.HSVToColor(floatArrayOf(p.toFloat(), 1f, 1f))); preview.invalidate() } }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        })
    }

    private fun field(hint: String, key: String) {
        val e = EditText(this).apply { setText(P.s(this@MainActivity, key)); this.hint = hint; setTextColor(Color.WHITE); setHintTextColor(0xFF777788.toInt()); textSize = 14f }
        e.doAfterTextChanged { P.put(this, key, it.toString()) }
        box.addView(e)
    }
}
