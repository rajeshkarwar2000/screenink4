package com.example.screenink

import android.content.Context

object P {
    val DI = mapOf("laserSize" to 16, "laserTime" to 800, "laserColor" to 0xFFFF1744.toInt(), "color" to 0xFFE53935.toInt(),
        "penSize" to 6, "brushSize" to 22, "hlSize" to 44, "eraserSize" to 70, "stampSize" to 110)
    val DS = mapOf("apiKey" to "", "model" to "gemini-2.5-flash",
        "prompt" to "Identify what is in this image and explain it briefly. If it contains a question or problem, answer or solve it.")
    val RANGE = mapOf("laserSize" to (4..60), "penSize" to (1..40), "brushSize" to (4..80),
        "hlSize" to (8..100), "eraserSize" to (10..150), "stampSize" to (30..300))
    private fun sp(c: Context) = c.getSharedPreferences("ink", 0)
    fun i(c: Context, k: String): Int = sp(c).getInt(k, DI[k]!!)
    fun s(c: Context, k: String): String = sp(c).getString(k, DS[k]!!) ?: DS[k]!!
    fun put(c: Context, k: String, v: Int) = sp(c).edit().putInt(k, v).apply()
    fun put(c: Context, k: String, v: String) = sp(c).edit().putString(k, v).apply()
    fun key(t: Tool) = when (t) {
        Tool.LASER -> "laserSize"; Tool.BRUSH -> "brushSize"; Tool.HIGHLIGHTER -> "hlSize"
        Tool.ERASER -> "eraserSize"; Tool.STAMP -> "stampSize"; else -> "penSize"
    }
}
