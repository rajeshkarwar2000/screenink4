package com.example.screenink

import android.app.*
import android.content.*
import android.content.pm.ServiceInfo
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.MediaStore
import android.util.Base64
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL

class MaxScroll(c: Context, private val maxH: Int) : ScrollView(c) {
    override fun onMeasure(w: Int, h: Int) = super.onMeasure(w, MeasureSpec.makeMeasureSpec(maxH, MeasureSpec.AT_MOST))
}

class OverlayService : Service() {
    companion object { var running = false }

    private lateinit var wm: WindowManager
    private lateinit var draw: DrawView
    private lateinit var root: LinearLayout
    private lateinit var drawLp: WindowManager.LayoutParams
    private lateinit var rootLp: WindowManager.LayoutParams
    private val dm = DisplayMetrics()
    private val handler = Handler(Looper.getMainLooper())
    private var proj: MediaProjection? = null
    private var reader: ImageReader? = null
    private var vd: VirtualDisplay? = null
    private var lastFrame: Bitmap? = null
    private var pending: Pair<Rect, Boolean>? = null
    private var answer: View? = null
    private var drawing = true
    private var selCell: TextView? = null
    private var modeCell: TextView? = null
    private val FL = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS

    private fun lp(w: Int, h: Int) = WindowManager.LayoutParams(w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, FL, PixelFormat.TRANSLUCENT)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun bg(c: Int, r: Int = 10) = GradientDrawable().apply { setColor(c); cornerRadius = dp(r).toFloat() }
    override fun onBind(i: Intent?): IBinder? = null

    private fun notif(): Notification {
        val stop = PendingIntent.getService(this, 0, Intent(this, OverlayService::class.java).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE)
        val open = PendingIntent.getActivity(this, 1, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(this, "ink").setSmallIcon(android.R.drawable.ic_menu_edit).setContentTitle("ScreenInk is active")
            .setContentText("Tap to open settings").setContentIntent(open)
            .addAction(Notification.Action.Builder(android.R.drawable.ic_delete, "Stop", stop).build()).build()
    }

    private fun fg(proj: Boolean) {
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, notif(), ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE or (if (proj) ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION else 0))
        else startForeground(1, notif())
    }

    override fun onCreate() {
        super.onCreate(); running = true
        getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel("ink", "ScreenInk", NotificationManager.IMPORTANCE_LOW))
        fg(false)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(dm)
        draw = DrawView(this); drawLp = lp(-1, -1); wm.addView(draw, drawLp)
        buildPanel()
    }

    private fun buildPanel() {
        val bubble = TextView(this).apply {
            text = "✨"; textSize = 26f; gravity = Gravity.CENTER
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xFF6A1B9A.toInt(), 0xFFE53935.toInt())).apply { shape = GradientDrawable.OVAL }
        }
        val inner = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(8), dp(8), dp(8)) }
        val panel = MaxScroll(this, (dm.heightPixels * 0.8).toInt()).apply { addView(inner); background = bg(0xE61E1E28.toInt(), 16) }
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(bubble, LinearLayout.LayoutParams(dp(56), dp(56)))
            addView(panel, LinearLayout.LayoutParams(dp(240), -2).apply { topMargin = dp(6) })
        }
        fun title(s: String) = inner.addView(TextView(this).apply { text = s; textSize = 11f; setTextColor(0xFF9E9EB8.toInt()); setPadding(dp(2), dp(8), 0, dp(2)) })
        fun mark(v: TextView) { selCell?.background = bg(0x33FFFFFF); v.background = bg(0xCCE53935.toInt()); selCell = v }
        fun grid(cols: Int, labels: List<String>, click: (Int, TextView) -> Unit): List<TextView> {
            val g = GridLayout(this).apply { columnCount = cols }; val cells = ArrayList<TextView>()
            labels.forEachIndexed { i, s ->
                val c = TextView(this).apply { text = s; textSize = 20f; gravity = Gravity.CENTER; setTextColor(Color.WHITE); background = bg(0x33FFFFFF) }
                c.setOnClickListener { click(i, c) }; cells.add(c)
                g.addView(c, GridLayout.LayoutParams().apply { width = dp(52); height = dp(52); setMargins(dp(2), dp(2), dp(2), dp(2)) })
            }
            inner.addView(g); return cells
        }
        val sizeLbl = TextView(this).apply { setTextColor(Color.WHITE); textSize = 12f }
        val sizeBar = SeekBar(this).apply { max = 100 }
        fun sync() {
            val k = P.key(draw.tool); val r = P.RANGE[k]!!; val v = P.i(this, k)
            sizeLbl.text = "Size  $v px"; sizeBar.progress = (v - r.first) * 100 / (r.last - r.first)
        }
        sizeBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                if (!u) return
                val k = P.key(draw.tool); val r = P.RANGE[k]!!; val v = r.first + p * (r.last - r.first) / 100
                P.put(this@OverlayService, k, v); sizeLbl.text = "Size  $v px"
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        fun pick(t: Tool, v: TextView, st: String? = null) { draw.tool = t; if (st != null) draw.stamp = st; setDrawing(true); mark(v); sync() }

        val tools = listOf(Tool.LASER to "🔴", Tool.PEN to "✏️", Tool.BRUSH to "🖌️", Tool.HIGHLIGHTER to "🖍️", Tool.ERASER to "🧽",
            Tool.LINE to "╱", Tool.ARROW to "➜", Tool.RECT to "▭", Tool.OVAL to "◯")
        title("TOOLS"); val tc = grid(4, tools.map { it.second }) { i, v -> pick(tools[i].first, v) }
        val stamps = listOf("⭐", "✅", "❌", "❤️", "❓", "❗", "👍", "🔥")
        title("STAMPS"); grid(4, stamps) { i, v -> pick(Tool.STAMP, v, stamps[i]) }
        title("SIZE"); inner.addView(sizeLbl); inner.addView(sizeBar)
        title("COLOR")
        val sw = GridLayout(this).apply { columnCount = 5 }
        intArrayOf(0xFFFF1744.toInt(), 0xFFFF9100.toInt(), 0xFFFFEA00.toInt(), 0xFF00E676.toInt(), 0xFF00E5FF.toInt(),
            0xFF2979FF.toInt(), 0xFFD500F9.toInt(), 0xFFFF4081.toInt(), Color.WHITE, Color.BLACK).forEach { c ->
            val v = View(this).apply { background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(c); setStroke(3, 0x88FFFFFF.toInt()) } }
            v.setOnClickListener { P.put(this, if (draw.tool == Tool.LASER) "laserColor" else "color", c) }
            sw.addView(v, GridLayout.LayoutParams().apply { width = dp(36); height = dp(36); setMargins(dp(4), dp(4), dp(4), dp(4)) })
        }
        inner.addView(sw)
        inner.addView(SeekBar(this).apply {
            max = 360
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                    if (u) P.put(this@OverlayService, if (draw.tool == Tool.LASER) "laserColor" else "color", Color.HSVToColor(floatArrayOf(p.toFloat(), 1f, 1f)))
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })
        title("ACTIONS")
        val ac = grid(4, listOf("↩️", "🗑️", "✂️", "🔍", "👆", "⚙️", "✖️")) { i, _ ->
            when (i) {
                0 -> draw.undo(); 1 -> draw.clearAll(); 2 -> select(false); 3 -> select(true); 4 -> setDrawing(!drawing)
                5 -> startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                6 -> stopSelf()
                else -> {}
            }
        }
        modeCell = ac[4]; pick(Tool.LASER, tc[0])

        rootLp = lp(-2, -2).apply { gravity = Gravity.TOP or Gravity.START; x = dp(8); y = dp(120) }
        wm.addView(root, rootLp)
        var dx = 0f; var dy = 0f; var ox = 0; var oy = 0; var moved = false
        bubble.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; ox = rootLp.x; oy = rootLp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    if (Math.abs(e.rawX - dx) > 12 || Math.abs(e.rawY - dy) > 12) moved = true
                    if (moved) { rootLp.x = ox + (e.rawX - dx).toInt(); rootLp.y = oy + (e.rawY - dy).toInt(); wm.updateViewLayout(root, rootLp) }
                }
                MotionEvent.ACTION_UP -> if (!moved) panel.visibility = if (panel.visibility == View.VISIBLE) View.GONE else View.VISIBLE
            }
            true
        }
    }

    private fun setDrawing(on: Boolean) {
        drawing = on; modeCell?.text = if (on) "👆" else "✍️"
        drawLp.flags = if (on) drawLp.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv() else drawLp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        wm.updateViewLayout(draw, drawLp)
    }

    private fun select(ai: Boolean) {
        root.visibility = View.INVISIBLE
        val holder = arrayOfNulls<View>(1)
        val sv = SelectView(this, ai) { r ->
            holder[0]?.let { wm.removeView(it) }
            if (r == null) root.visibility = View.VISIBLE else begin(r, ai)
        }
        holder[0] = sv
        wm.addView(sv, lp(-1, -1))
    }

    private fun begin(r: Rect, ai: Boolean) {
        if (proj != null) { grab(r, ai); return }
        pending = r to ai
        startActivity(Intent(this, CaptureActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        when (i?.action) {
            "STOP" -> stopSelf()
            "DENIED" -> { pending = null; root.visibility = View.VISIBLE; Toast.makeText(this, "Screen capture permission was declined", Toast.LENGTH_SHORT).show() }
            "PROJ" -> { @Suppress("DEPRECATION") val d = i!!.getParcelableExtra<Intent>("data"); if (d != null) startProj(i.getIntExtra("code", 0), d) }
        }
        return START_NOT_STICKY
    }

    private fun startProj(code: Int, data: Intent) {
        fg(true)
        val p = getSystemService(MediaProjectionManager::class.java).getMediaProjection(code, data)
        p.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { vd?.release(); reader?.close(); vd = null; reader = null; proj = null }
        }, handler)
        proj = p
        val w = dm.widthPixels; val h = dm.heightPixels
        reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        vd = p.createVirtualDisplay("ink", w, h, dm.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, handler)
        pending?.let { pd -> handler.postDelayed({ grab(pd.first, pd.second) }, 500) }; pending = null
    }

    private fun grab(r: Rect, ai: Boolean) {
        handler.postDelayed({
            val img = try { reader?.acquireLatestImage() } catch (e: Exception) { null }
            if (img != null) {
                val pl = img.planes[0]
                val full = Bitmap.createBitmap(pl.rowStride / pl.pixelStride, img.height, Bitmap.Config.ARGB_8888)
                full.copyPixelsFromBuffer(pl.buffer)
                lastFrame = Bitmap.createBitmap(full, 0, 0, img.width, img.height); img.close()
            }
            root.visibility = View.VISIBLE
            val f = lastFrame
            if (f == null) { Toast.makeText(this, "Capture failed, try again", Toast.LENGTH_SHORT).show(); return@postDelayed }
            val l = r.left.coerceIn(0, f.width - 2); val t = r.top.coerceIn(0, f.height - 2)
            val crop = Bitmap.createBitmap(f, l, t, minOf(r.width(), f.width - l), minOf(r.height(), f.height - t))
            if (ai) ask(crop) else save(crop)
        }, 400)
    }

    private fun save(b: Bitmap) {
        val v = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "ScreenInk_${System.currentTimeMillis()}.png")
            put(MediaStore.Images.Media.MIME_TYPE, "image/png")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/ScreenInk")
        }
        val u = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v)
        if (u != null) {
            contentResolver.openOutputStream(u)?.use { b.compress(Bitmap.CompressFormat.PNG, 100, it) }
            Toast.makeText(this, "Saved to Pictures/ScreenInk", Toast.LENGTH_SHORT).show()
        }
    }

    private fun ask(crop: Bitmap) {
        answer?.let { runCatching { wm.removeView(it) } }
        val tv = TextView(this).apply { text = "Thinking…"; textSize = 16f; setTextColor(Color.WHITE); setPadding(dp(4), dp(8), dp(4), dp(8)) }
        val sc = MaxScroll(this, (dm.heightPixels * 0.4).toInt()).apply { addView(tv) }
        val thumb = ImageView(this).apply { setImageBitmap(crop); adjustViewBounds = true; maxHeight = dp(160) }
        fun chip(s: String) = TextView(this).apply { text = s; textSize = 15f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; background = bg(0x33FFFFFF); setPadding(dp(16), dp(10), dp(16), dp(10)) }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = bg(0xF2202030.toInt(), 18); setPadding(dp(14), dp(12), dp(14), dp(12)) }
        val bar = LinearLayout(this).apply { gravity = Gravity.END }
        val copy = chip("📋 Copy").apply { setOnClickListener { getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("ai", tv.text)) } }
        val close = chip("✖ Close").apply { setOnClickListener { runCatching { wm.removeView(box) }; answer = null } }
        bar.addView(copy); bar.addView(close, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(8) })
        box.addView(TextView(this).apply { text = "✨ Gemini"; textSize = 14f; setTextColor(0xFFFF6E6E.toInt()) })
        box.addView(thumb); box.addView(sc); box.addView(bar)
        wm.addView(box, lp(minOf(dm.widthPixels - dp(32), dp(560)), -2).apply { gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; y = dp(24) })
        answer = box
        val key = P.s(this, "apiKey").trim()
        if (key.isEmpty()) { tv.text = "Add your Gemini API key in the ScreenInk app (Ask AI section)."; return }
        val prompt = P.s(this, "prompt"); val model = P.s(this, "model").trim()
        Thread { val res = gemini(crop, prompt, key, model); handler.post { tv.text = res.replace("**", "").replace("\n* ", "\n• ") } }.start()
    }

    private fun gemini(b: Bitmap, prompt: String, key: String, model: String): String {
        return try {
            val s = minOf(1f, 1280f / maxOf(b.width, b.height))
            val sb = if (s < 1f) Bitmap.createScaledBitmap(b, (b.width * s).toInt(), (b.height * s).toInt(), true) else b
            val bo = ByteArrayOutputStream(); sb.compress(Bitmap.CompressFormat.JPEG, 85, bo)
            val b64 = Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP)
            val parts = JSONArray().put(JSONObject().put("text", prompt))
                .put(JSONObject().put("inline_data", JSONObject().put("mime_type", "image/jpeg").put("data", b64)))
            val body = JSONObject().put("contents", JSONArray().put(JSONObject().put("parts", parts)))
            val c = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent").openConnection() as HttpURLConnection
            c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 15000; c.readTimeout = 60000
            c.setRequestProperty("Content-Type", "application/json"); c.setRequestProperty("x-goog-api-key", key)
            c.outputStream.use { it.write(body.toString().toByteArray()) }
            val code = c.responseCode
            val txt = (if (code < 400) c.inputStream else c.errorStream).bufferedReader().readText()
            if (code >= 400) "Error $code: " + runCatching { JSONObject(txt).getJSONObject("error").getString("message") }.getOrDefault(txt.take(200))
            else JSONObject(txt).getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
        } catch (e: Exception) { "Could not get an answer: ${e.message}" }
    }

    override fun onDestroy() {
        running = false
        for (v in listOf<View?>(draw, root, answer)) v?.let { runCatching { wm.removeView(it) } }
        vd?.release(); reader?.close(); proj?.stop()
        super.onDestroy()
    }
}
